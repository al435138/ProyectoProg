package Pruebas;

public @interface IncludeClassNamePatterns {
}
