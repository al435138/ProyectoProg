package Pruebas;

public @interface Suite {
}
