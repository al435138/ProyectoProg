package Pruebas;

public @interface SelectPackages {
}
