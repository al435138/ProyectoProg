package Pruebas;

public @interface SuiteDisplayName {
}
