package es.uji.al435138.recommender;

public class LikedItemNotFoundException extends Throwable {
}
