package es.uji.al435138.lectura.recommender;

public class LikedItemNotFoundException extends Throwable {
}
